from django.http import HttpResponse
from django.views import View
from django.shortcuts import render, redirect
import json
 
def index(request):
    
    return HttpResponse("Hola Mundo")

class Inicio(View):
    template_name = "home.html"

    def post(self, request):
        return render(request)
    
    def get(self, request):
        datos = {
        "Name" : "Paco",
        "LastName1" : "Gaitan",
        "LastName2" : "Bandala",
        "Birthday" : "02/08/1988",
        "Cellphone" : "(33) 1140 - 7593",
        "Email" : "pacogaitan@hotmail.com",
        "Address" : "Av. Vallarta 7281",
        "Gender" : "Male",
        "Objective" : "Professional Development",
        "Salary" : "50,000"
        }
        skills = {
            "skills2": ("Finance", "Project Management", "Basic Python")
        }
        jobs = { "workplace" : "IBM", "startyear" : 2012, "endyear" : 2022, "position" : "Financial Analyst", 
                   "workplace2" : "HPE", "startyear2" : 2022, "position2" : "Business Planning Manager"}    
        master = {**datos, **skills, **jobs}
  
        return render(request, self.template_name, master)
    

